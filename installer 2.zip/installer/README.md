# FlatSat Device Simulator - Installation & Operation Guide

## Overview
The FlatSat Device Simulator is a comprehensive testing system that simulates satellite devices (ARS, Magnetometer, Reaction Wheel) by receiving MATLAB data via TCP/IP and outputting device-specific packets to USB ports. It supports both development testing with loopback cables and production use with real devices.

## Installation

### Prerequisites
- Python 3.8 or higher
- Required Python packages (install with pip):
  ```bash
  pip install pyserial python-can
  ```

### Installation Steps
1. Copy the entire `installer` directory to your test machine
2. Navigate to the installer directory:
   ```bash
   cd installer
   ```
3. Install Python dependencies:
   ```bash
   pip install pyserial python-can
   ```
   Or run the automated installer:
   ```bash
   ./install.sh
   ```

### Quick Fix for Missing Dependencies
If you get `ModuleNotFoundError` errors, run:
```bash
./fix_dependencies.sh
```

## Configuration

### Configuration Files
- `config/simulator_config.json` - Main configuration (production mode)
- `config/simulator_config_with_options.json` - Example with all options
- `config/simulator_config_loopback.json` - Development mode with loopback

### Key Configuration Options

#### USB Loopback Testing (Development)
```json
{
  "devices": {
    "ars": {
      "usb_loopback_enabled": true,
      "usb_loopback_port": "/dev/ttyUSB0",
      "log_packets_to_file": false
    }
  }
}
```

#### Packet Logging (Production)
```json
{
  "devices": {
    "ars": {
      "usb_loopback_enabled": false,
      "log_packets_to_file": true,
      "packet_log_file": "ars_packets.log"
    }
  }
}
```

## Operation Modes

### Mode 1: MATLAB Simulator Testing (Local Development)

#### Setup
1. **Terminal 1 - Start Device Simulator:**
   ```bash
   python flatsat_device_simulator.py --config config/simulator_config.json --enable-ars --debug --listen-port 5001
   ```

2. **Terminal 2 - Start MATLAB Simulator:**
   ```bash
   python examples/matlab_tcp_sender.py --enable-ars --target-port 5001 --duration 60
   ```

#### Expected Output
- Device simulator receives TCP data on port 5001
- MATLAB simulator sends 8-byte floats every 10ms
- Device simulator processes data and outputs device packets
- Real-time statistics displayed

#### Testing All Devices
```bash
# Start simulator with all devices
python flatsat_device_simulator.py --config config/simulator_config.json --enable-ars --enable-magnetometer --enable-reaction-wheel --listen-port 5001

# Send test data for all devices
python examples/matlab_tcp_sender.py --enable-ars --enable-magnetometer --enable-reaction-wheel --target-port 5001 --duration 30
```

### Mode 2: Real MATLAB System Testing (Production)

#### Setup
1. **Configure MATLAB System:**
   - Ensure MATLAB is sending data to the correct IP address and ports
   - Default configuration expects data on `127.0.0.1:5001`
   - Modify `matlab_server_ip` in config if needed

2. **Start Device Simulator:**
   ```bash
   python flatsat_device_simulator.py --config config/simulator_config.json --enable-ars --listen-port 5001
   ```

3. **Monitor Output:**
   - Check console output for data reception
   - Monitor packet log files if logging enabled
   - Verify USB port connections

#### MATLAB Data Format
MATLAB should send data in the following format:
- **ARS**: 6 floats (primary data only) or 12 floats (primary + redundant)
- **Magnetometer**: 3 floats (X, Y, Z magnetic field)
- **Reaction Wheel**: 4 floats (speed, current, temperature, voltage)

Each float is 8 bytes (64-bit), sent every 10ms.

## USB Port Configuration

### Default Port Assignments
- **ARS**: `/dev/ttyUSB0` (115200 baud, Serial)
- **Magnetometer**: `/dev/ttyUSB1` (115200 baud, CAN)
- **Reaction Wheel**: `/dev/ttyUSB2` (115200 baud, TCP)

### Hardware Setup

#### Development Mode (Loopback Testing)
1. Connect USB-to-USB loopback cables:
   - `/dev/ttyUSB0` → Loopback
   - `/dev/ttyUSB1` → Loopback  
   - `/dev/ttyUSB2` → Loopback

2. Enable loopback testing in config:
   ```json
   "usb_loopback_enabled": true
   ```

#### FTDI RS232 Devices
For RS232 FTDI USB-to-serial converters:
1. Use the FTDI-optimized configuration:
   ```bash
   python3 flatsat_device_simulator.py --config config/simulator_config_ftdi_loopback.json --enable-ars
   ```

2. Test FTDI loopback specifically:
   ```bash
   python3 examples/test_ftdi_loopback.py
   ```

3. FTDI-specific features:
   - Automatic port detection (`/dev/ttyUSB*`, `/dev/tty.usbserial*`)
   - Proper DTR/RTS initialization
   - Buffer reset and flow control configuration
   - Enhanced error handling for FTDI devices

#### Production Mode (Real Devices)
1. Connect real devices to assigned USB ports
2. Enable packet logging in config:
   ```json
   "log_packets_to_file": true
   ```

## Testing & Validation

### USB Loopback Testing
```bash
# Test loopback functionality (standard USB)
python examples/test_usb_loopback.py

# Test loopback functionality (FTDI RS232 optimized)
python examples/test_ftdi_loopback.py

# Demo configuration options
python examples/demo_config_options.py --demo both
```

### Packet Analysis
When packet logging is enabled, files are created in `packet_logs/` directory:
- `ars_packets.log` - ARS device packets
- `magnetometer_packets.log` - Magnetometer packets
- `reaction_wheel_packets.log` - Reaction wheel packets

Log format: `TIMESTAMP | PACKET_SIZE | HEX_DATA`

### Data Validation
- **ARS**: Honeywell Rate Sensor protocol (sync bytes, angular rates, status words, CRC)
- **Magnetometer**: CAN/RS485 protocol with status codes
- **Reaction Wheel**: TCP protocol with telemetry data

## Troubleshooting

### Common Issues

#### 1. Missing Dependencies
```bash
# Error: ModuleNotFoundError: No module named 'can'
# Solution: Run the dependency fix script
./fix_dependencies.sh

# Or install manually
pip3 install python-can pyserial flask
```

#### 2. Port Already in Use
```bash
# Check what's using port 5000
lsof -i :5000

# Use different port
python flatsat_device_simulator.py --listen-port 5001
```

#### 2. USB Port Not Found
```bash
# Check available USB ports
ls /dev/ttyUSB*

# Update configuration with correct port
```

#### 3. MATLAB Connection Refused
- Verify MATLAB is sending to correct IP/port
- Check firewall settings
- Ensure simulator is running before MATLAB

#### 4. CAN Bus Errors
- Install CAN utilities: `sudo apt-get install can-utils`
- Setup CAN interface: `sudo ip link set can0 up type can bitrate 500000`

### Debug Mode
Enable debug logging for detailed information:
```bash
python flatsat_device_simulator.py --debug --enable-ars
```

## Command Line Options

### Main Simulator
```bash
python flatsat_device_simulator.py [OPTIONS]

Options:
  --config FILE              Configuration file (default: config/simulator_config.json)
  --enable-ars               Enable ARS device
  --enable-magnetometer      Enable Magnetometer device
  --enable-reaction-wheel    Enable Reaction Wheel device
  --listen-port PORT         TCP listen port (default: 5000)
  --debug                    Enable debug logging
  --help                     Show help message
```

### MATLAB Simulator
```bash
python examples/matlab_tcp_sender.py [OPTIONS]

Options:
  --enable-ars               Enable ARS data transmission
  --enable-magnetometer      Enable Magnetometer data transmission
  --enable-reaction-wheel    Enable Reaction Wheel data transmission
  --target-port PORT         Target TCP port (default: 5000)
  --duration SECONDS         Test duration (default: 30)
  --endianness {little,big}  Data endianness (default: little)
  --help                     Show help message
```

## File Structure
```
installer/
├── flatsat_device_simulator.py    # Main application
├── tcp_receiver.py               # TCP/IP receiver
├── packet_logger.py              # Packet logging system
├── usb_loopback_tester.py         # USB loopback testing
├── config/                        # Configuration files
│   ├── simulator_config.json
│   ├── simulator_config_with_options.json
│   └── simulator_config_loopback.json
├── device_encoders/              # Device-specific encoders
│   ├── ars_encoder.py
│   ├── magnetometer_encoder.py
│   └── reaction_wheel_encoder.py
├── output_transmitters/          # Output protocols
│   ├── serial_transmitter.py
│   ├── can_transmitter.py
│   └── tcp_transmitter.py
├── examples/                     # Test and example scripts
│   ├── matlab_tcp_sender.py
│   ├── test_usb_loopback.py
│   └── demo_config_options.py
└── README.md                     # This file
```

## Support
For technical support or questions:
1. Check the troubleshooting section above
2. Review configuration files for proper setup
3. Enable debug mode for detailed logging
4. Check packet log files for data analysis

## Version Information
- Version: 1.0
- Last Updated: October 2024
- Compatible with: Python 3.8+, MATLAB R2019b+
