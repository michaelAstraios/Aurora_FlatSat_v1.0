#!/bin/bash
# Quick fix for missing dependencies on test machine

echo "=========================================="
echo "FlatSat Device Simulator - Dependency Fix"
echo "=========================================="
echo ""

# Check if we're in the right directory
if [ ! -f "flatsat_device_simulator.py" ]; then
    echo "ERROR: Please run this script from the installer directory"
    echo "Current directory: $(pwd)"
    exit 1
fi

echo "Installing missing dependencies..."

# Install python-can specifically
echo "Installing python-can..."
pip3 install python-can

# Also install pyserial in case it's missing
echo "Installing pyserial..."
pip3 install pyserial

# Install Flask for the rate sensor test generator
echo "Installing Flask..."
pip3 install flask

echo ""
echo "Verifying installations..."

# Test imports
python3 -c "import can; print('✓ python-can: OK')" || {
    echo "✗ ERROR: python-can installation failed"
    echo "Try: pip3 install --user python-can"
    exit 1
}

python3 -c "import serial; print('✓ pyserial: OK')" || {
    echo "✗ ERROR: pyserial installation failed"
    echo "Try: pip3 install --user pyserial"
    exit 1
}

python3 -c "import flask; print('✓ Flask: OK')" || {
    echo "✗ ERROR: Flask installation failed"
    echo "Try: pip3 install --user flask"
    exit 1
}

echo ""
echo "=========================================="
echo "Dependencies Fixed Successfully!"
echo "=========================================="
echo ""
echo "You can now run the simulator:"
echo "  python3 flatsat_device_simulator.py --config config/simulator_config.json --enable-ars --listen-port 5001"
echo ""
